/*
	Class: CSE 3330
	Semester: Fall 2016
	Student Name: Nghiem, Harris, hpn2896
	Student ID: 1000572896
	Assignment: project #1
*/

DROP TABLE 	Airport, Flight, FlightInstance, FlightLeg, 
			FlightLegDistance, Passenger, Plane, PlaneSeats, 
			PlaneType, Pilot, Reservation;