/*
	Class: CSE 3330
	Semester: Fall 2016
	Student Name: Nghiem, Harris, hpn2896
	Student ID: 1000572896
	Assignment: project #1
*/

UPDATE Pilot set Name = 'HARRY' where Name = 'JONES';
UPDATE Plane set MAKER = 'AMERICAN' where MAKER = 'BOEING';
UPDATE Reservation set PASSID = 56567 where PASSID = 7654321;
UPDATE PlaneSeats set MAKER = 'EE' where MAKER = 'AA';
UPDATE Airport set CODE = 'TXT' where CODE = 'DFW';

