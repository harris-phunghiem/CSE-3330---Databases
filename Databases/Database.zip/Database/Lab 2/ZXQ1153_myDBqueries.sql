{\rtf1\ansi\ansicpg1252\cocoartf1344\cocoasubrtf720
{\fonttbl\f0\fswiss\fcharset0 ArialMT;\f1\froman\fcharset0 Times-Roman;\f2\fswiss\fcharset0 Helvetica;
}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sa240

\f0\fs32 \cf0 \expnd0\expndtw0\kerning0
-- Class: CSE 3330\uc0\u8232 -- Semester: Sprint 2015\u8232 -- Student Name: Qureshi, Zubair\
-- Student ID: \expnd0\expndtw0\kerning0
1000801153\expnd0\expndtw0\kerning0
\uc0\u8232 -- Assignment: Project # 2
\f1\fs24 \expnd0\expndtw0\kerning0
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f2 \cf0 \kerning1\expnd0\expndtw0 \
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 -- #1 This query selects the ID and Name from the pilot table and only shows the information on pilots that were hired before the date.\
Select ID, NAME From Pilot Where DateHired < '1995-01-01 00:00:00';\
\
\
-- #2 This query selects the city of every flight number in the flight leg table and I joined the flightless and airport based on the airport code and then join the flight table to make sure the number matches the flights in flightless and then it prints the flight number and city for each of those flights.\
Select f.FLNO, City\
From Airport a\
Join FlightLeg flg On a.code = flg.FromA\
Join Flight f On f.flno = flg.flno;\
\
\
-- #3 This query basically gives a count of the number of planes that were last maintained between the two dates in the plane table and i used a between clause.\
Select Count(*) NumOfPlane From Plane Where LastMaint Between '2002-09-03 00:00:00' and '2002-09-05 00:00:00';\
\
\
-- #4 This query I joined reservation and airport to get a table with passenger id and city code together and then i compared the city code to TX and the date and to see if the flight qualifies i also check to see if date cancelled is NULL.\
Select p.name, p.phone, a.city, a.state From Passenger p\
Join Reservation r On p.id = r.passid\
Join Airport a On r.froma = a.code\
where a.state = 'TX' \
and r.fdate > '2002-10-04 00:00:00'\
and r.datecancelled is NULL;\
\
\
-- #7 In this query to retrieve last maintained list i joined airport and plane table and then select city state and plane id to print.\
Select a.city, a.state, p.id \
From Airport a\
Join Plane p On p.lastmainta = a.code;\
\
\
-- #8 In this query to retrieve passengers who are flying to any airport in new york i joined passenger and reservation based on passenger id and then joined the airport table only were the state is NY and it was printing duplicates of passenger names so i used the distinct clause.\
Select distinct p.name \
From Passenger p \
Join Reservation r On r.passid = p.id\
Join airport a On a.code = r.toa\
where a.state = 'NY';\
\
\
-- #9 In this query i joined the airport and plane table and then joined another table that only has states have two airports to the airport/plane table based on state and then grouping them based on the state and printing the state and number of planes at the airport that were last maintained.\
Select a.State, count(*) NumOfPlane\
From Plane p\
Join airport a On a.code = p.lastmainta\
join (Select * From airport group by state having count(*) > 1) b On b.state = a.state\
group by a.state;\
\
\
-- #5 In this query i joined flightleginstance table to pilot based on the pilot id in both table and then grouped the table by flight number and pilot and only if there are more then 1 and if it meets this requirement then it will print the flight number date and name of the pilot.\
Select flgi.FLNO, flgi.FDate, p.Name\
from FlightLegInstance flgi\
Join pilot p on p.id = flgi.pilot\
group by flno, pilot having count(*) > 1;\
\
\
-- #6 In this query i did a left join on flight leg and any flight that meets the requirement that FromA and ToA on the other tables match and the sequence of the flight is greater then on the first table then it will be joined and if there are more then 1 occurrences then it will print the flight number and first and last destination.\
Select f1.FLNO, f1.FromA, f2.ToA\
From FlightLeg f1\
Left Join FlightLeg f2 on f1.ToA = f2.FromA and f1.flno = f2.flno and f1.seq < f2.seq\
group by flno having count(*) > 1;\
\
\
-- #10 In this query I joined reservation with flight leg if the flight number and city code match and also it can\'92t be cancelled then i grouped it based on sequence and flight number since those are the only two unique columns in the table and it prints the flight number and counts the number of time each flight number appeared based on flight leg table and prints the number. \
Select r.FLNO, count(*) SeatsOccupied\
From Reservation r\
join FlightLeg f on (f.flno = r.flno and f.froma = r.froma)\
where r.datecancelled is NULL\
group by seq, flno;}