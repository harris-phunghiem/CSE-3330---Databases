{\rtf1\ansi\ansicpg1252\cocoartf1344\cocoasubrtf720
{\fonttbl\f0\fswiss\fcharset0 ArialMT;\f1\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sa240

\f0\fs32 \cf0 \expnd0\expndtw0\kerning0
-- Class: CSE 3330\uc0\u8232 -- Semester: Spring 2015\u8232 -- Student Name: Zubair Qureshi\
-- Student ID: 1000801153\uc0\u8232 -- Assignment: project #1 
\f1\fs24 \kerning1\expnd0\expndtw0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 Drop Table FlightLegInstance, FlightLeg, Reservation, FlightInstance, Plane, Flight, Passenger, Pilot, PlaneSeats, PlaneType, Airport;}