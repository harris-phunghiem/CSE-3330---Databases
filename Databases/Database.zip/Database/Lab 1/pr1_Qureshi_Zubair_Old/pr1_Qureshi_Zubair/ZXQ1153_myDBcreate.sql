-- Class: CSE 3330 -- Semester: Spring 2015 -- Student Name: Zubair Qureshi
-- Student ID: 1000801153 -- Assignment: project #1 

CREATE TABLE `Airport` (   
`Code` varchar(3),
`City` varchar(50),
`State` varchar(4),
Constraint pk_Airport PRIMARY KEY (Code)
);

CREATE TABLE `PlaneType` (
`Maker` varchar(10),
`Model` varchar(10),
`FlyingSpeed` int(4),
`GroundSpeed` int(4),
Constraint pk_PlaneType PRIMARY KEY (Maker, Model)
);

CREATE TABLE `PlaneSeats` (
`Maker` varchar(10),
`Model` varchar(10),
`SeatType` char,
`NoOfSeats`  int(4),
PRIMARY KEY (Maker, Model, SeatType),
FOREIGN KEY (`Maker`, `Model`) REFERENCES PlaneType(`Maker`,`Model`)
);

CREATE TABLE `Pilot` (
`ID` int(1),
`Name` varchar(50),
`DateHired` datetime,
Constraint pk_Pilot PRIMARY KEY (ID)
);

CREATE TABLE `Passenger` (
`ID` int(3),
`Name` varchar(50),
`Phone` varchar(20),
Constraint pk_Passenger PRIMARY KEY (ID)
);

CREATE TABLE `Flight` (
`FLNO` int(4),
`Meal` varchar(50),
`Smoking` varchar(1),
Constraint pk_Flight PRIMARY KEY (FLNO)
);

CREATE TABLE `Plane` (
`ID` int(3),
`Maker` varchar(10),
`Model` varchar(10),
`LastMaint` datetime,
`LastMaintA` varchar(3),
Constraint pk_Plane PRIMARY KEY (ID),
Constraint fk_MakerModel FOREIGN KEY (`Maker`, `Model`) REFERENCES PlaneType(`Maker`, `Model`),
Constraint fk_LastMaintA FOREIGN KEY (LastMaintA) REFERENCES Airport(Code)
);

CREATE TABLE `FlightInstance` (
`FLNO` int(4),
`FDate`datetime,
Constraint pk_FlightInstance PRIMARY KEY (FLNO, FDate),
Constraint fk_FlightInstance FOREIGN KEY (FLNO) REFERENCES Flight(FLNO)
);

CREATE TABLE `Reservation` (
`PassID` int(3),
`FLNO` int(4),
`FDate` datetime,
`FromA` varchar(3),
`ToA` varchar(3),
`SeatClass` char,
`DateBooked` datetime,
`DateCancelled` datetime,
Constraint pk_Reservation PRIMARY KEY (PassID, FLNO, FDate),
Constraint fk_FDateFLNO FOREIGN KEY (FLNO, FDate) REFERENCES FlightInstance(FLNO, FDate),
Constraint fk_PassID FOREIGN KEY (PassID) REFERENCES Passenger(ID),
Constraint fk_FromA FOREIGN KEY (FromA) REFERENCES Airport(Code),
Constraint fk_ToA FOREIGN KEY (ToA) REFERENCES Airport(Code)
);

CREATE TABLE `FlightLeg` (
`FLNO` int(4),
`Seq` int(1),
`FromA` varchar(3),
`ToA` varchar(3),
`DeptTime` datetime,
`ArrTime` datetime,
`Plane` int(3),
Constraint pk_FlightLeg PRIMARY KEY (FLNO, Seq),
FOREIGN KEY (FLNO) REFERENCES Flight(FLNO),
FOREIGN KEY (FromA) REFERENCES Airport(`Code`),
FOREIGN KEY (ToA) REFERENCES Airport(`Code`),
FOREIGN KEY (Plane) REFERENCES Plane(ID)
);

CREATE TABLE `FlightLegInstance` (
`Seq` int(1),
`FLNO` int(4),
`FDate` datetime,
`ActDept` datetime,
`ActArr` datetime,
`Pilot` int(1),
PRIMARY KEY (`Seq`, `FLNO`, `FDate`),
FOREIGN KEY (`FLNO`, `Seq`) REFERENCES FlightLeg(`FLNO`, `Seq`),
FOREIGN KEY (`FLNO`, `FDate`) REFERENCES FlightInstance(`FLNO`,`FDate`),
FOREIGN KEY (Pilot) REFERENCES Pilot(ID)
);
