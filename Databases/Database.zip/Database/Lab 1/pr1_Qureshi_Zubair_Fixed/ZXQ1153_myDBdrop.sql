-- Class: CSE 3330 -- Semester: Spring 2015 -- Student Name: Zubair Qureshi
-- Student ID: 1000801153 -- Assignment: project #1 

Drop Table FlightLegInstance, FlightLeg, Reservation, FlightInstance, Plane, Flight, Passenger, Pilot, PlaneSeats, PlaneType, Airport;
