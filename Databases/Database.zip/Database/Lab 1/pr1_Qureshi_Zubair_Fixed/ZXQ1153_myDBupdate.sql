-- Class: CSE 3330 -- Semester: Spring 2015 -- Student Name: Zubair Qureshi
-- Student ID: 1000801153 -- Assignment: project #1 

UPDATE Airport set City = 'xyz' WHERE Code = 'DFW';
INSERT INTO Passenger (`ID`, `Name`, `Phone`) VALUES (13, 'Zubair', '(972)888-1111');
DELETE from Passenger WHERE Name = 'Zubair';