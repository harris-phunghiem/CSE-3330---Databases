-- Class: CSE 3330 -- Semester: Spring 2015 -- Student Name: Zubair Qureshi
-- Student ID: 1000801153 -- Assignment: project #1 

INSERT INTO Airport (Code, City, State) VALUES ('DFW', 'Dallas', 'TX');
INSERT INTO Airport (Code, City, State) VALUES ('LOG', 'Boston', 'MA');
INSERT INTO Airport (Code, City, State) VALUES ('ORD', 'Chicago', 'IL');
INSERT INTO Airport (Code, City, State) VALUES ('MDW', 'Chicago', 'IL');
INSERT INTO Airport (Code, City, State) VALUES ('JFK', 'New York', 'NY');
INSERT INTO Airport (Code, City, State) VALUES ('LGA', 'New York', 'NY');
INSERT INTO Airport (Code, City, State) VALUES ('INT', 'Houston', 'TX');
INSERT INTO Airport (Code, City, State) VALUES ('LAX', 'Los Angeles', 'CA');

INSERT INTO Flight (FLNO, Meal, Smoking) VALUES (1000, 'Bistro', 'Y');
INSERT INTO Flight (FLNO, Meal, Smoking) VALUES (1010, 'Meal', 'N');
INSERT INTO Flight (FLNO, Meal, Smoking) VALUES (1020, 'Meal', 'Y');
INSERT INTO Flight (FLNO, Meal, Smoking) VALUES (1030, 'Snack', 'N');
INSERT INTO Flight (FLNO, Meal, Smoking) VALUES (1040, 'Meal', 'N');

INSERT INTO FlightInstance (FLNO, FDate) VALUES (1000, '2002-10-5');
INSERT INTO FlightInstance (FLNO, FDate) VALUES (1000, '2002-10-6');
INSERT INTO FlightInstance (FLNO, FDate) VALUES (1000, '2002-10-7');
INSERT INTO FlightInstance (FLNO, FDate) VALUES (1010, '2002-10-5');
INSERT INTO FlightInstance (FLNO, FDate) VALUES (1010, '2002-10-6');
INSERT INTO FlightInstance (FLNO, FDate) VALUES (1020, '2002-10-5');
INSERT INTO FlightInstance (FLNO, FDate) VALUES (1030, '2002-10-5');
INSERT INTO FlightInstance (FLNO, FDate) VALUES (1040, '2002-10-7');

INSERT INTO PlaneType (Maker, Model, FlyingSpeed, GroundSpeed) VALUES ('MD', 'MD11', 600, 180);
INSERT INTO PlaneType (Maker, Model, FlyingSpeed, GroundSpeed) VALUES ('MD', 'SUPER80', 500, 170);
INSERT INTO PlaneType (Maker, Model, FlyingSpeed, GroundSpeed) VALUES ('BOEING', '727', 510, 160);
INSERT INTO PlaneType (Maker, Model, FlyingSpeed, GroundSpeed) VALUES ('BOEING', '757', 650, 160);
INSERT INTO PlaneType (Maker, Model, FlyingSpeed, GroundSpeed) VALUES ('AIRBUS', 'A300', 620, 150);
INSERT INTO PlaneType (Maker, Model, FlyingSpeed, GroundSpeed) VALUES ('AIRBUS', 'A320', 700, 180);

INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('AIRBUS', 'A300', 'E', 160);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('AIRBUS', 'A300', 'F', 20);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('AIRBUS', 'A320', 'E', 200);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('AIRBUS', 'A320', 'F', 30);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('BOEING', '727', 'E', 110);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('BOEING', '727', 'F', 10);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('BOEING', '757', 'E', 160);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('BOEING', '757', 'F', 20);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('MD', 'MD11', 'E', 150);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('MD', 'MD11', 'F', 20);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('MD', 'SUPER80', 'E', 90);
INSERT INTO PlaneSeats (Maker, Model, SeatType, NoOfSeats) VALUES ('MD', 'SUPER80', 'F', 10);

INSERT INTO Pilot (ID, Name, DateHired) VALUES (1, 'Jones', '1990-10-5');
INSERT INTO Pilot (ID, Name, DateHired) VALUES (2, 'Adams', '1990-6-1');
INSERT INTO Pilot (ID, Name, DateHired) VALUES (3, 'Walker', '1991-7-2');
INSERT INTO Pilot (ID, Name, DateHired) VALUES (4, 'Flores', '1992-4-1');
INSERT INTO Pilot (ID, Name, DateHired) VALUES (5, 'Thompson', '1992-4-10');
INSERT INTO Pilot (ID, Name, DateHired) VALUES (6, 'Dean', '1993-9-2');
INSERT INTO Pilot (ID, Name, DateHired) VALUES (7, 'Carter', '1994-8-1');
INSERT INTO Pilot (ID, Name, DateHired) VALUES (8, 'Mango', '1995-5-2');

INSERT INTO Passenger (ID, Name, Phone) VALUES (1, 'Jones', '(972)999-1111');
INSERT INTO Passenger (ID, Name, Phone) VALUES (2, 'James', '(214)111-9999');
INSERT INTO Passenger (ID, Name, Phone) VALUES (3, 'Henry', '(214)222-1111');
INSERT INTO Passenger (ID, Name, Phone) VALUES (4, 'Luis', '(972)111-3333');
INSERT INTO Passenger (ID, Name, Phone) VALUES (5, 'Howard', '(972)333-1111');
INSERT INTO Passenger (ID, Name, Phone) VALUES (6, 'Frank', '(214)111-5555');
INSERT INTO Passenger (ID, Name, Phone) VALUES (7, 'Frankel', '(972)111-2222');
INSERT INTO Passenger (ID, Name, Phone) VALUES (8, 'Bushnell', '(214)111-4444');
INSERT INTO Passenger (ID, Name, Phone) VALUES (9, 'Camden', '(214)222-5555');
INSERT INTO Passenger (ID, Name, Phone) VALUES (10, 'Max', '(972)444-1111');
INSERT INTO Passenger (ID, Name, Phone) VALUES (11, 'Flores', '(214)333-6666');
INSERT INTO Passenger (ID, Name, Phone) VALUES (12, 'Clinton', '(214)222-5555');

INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (1, 'MD', 'MD11', '2002-9-3', 'DFW');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (2, 'MD', 'MD11', '2002-9-4', 'MDW');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (3, 'MD', 'SUPER80', '2002-9-1', 'LAX');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (4, 'MD', 'SUPER80', '2002-9-3', 'ORD');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (5, 'MD', 'SUPER80', '2002-9-6', 'LGA');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (6, 'BOEING', '727', '2002-9-1', 'DFW');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (7, 'BOEING', '757', '2002-10-2', 'LAX');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (8, 'AIRBUS', 'A300', '2002-9-1', 'INT');
INSERT INTO Plane (ID, Maker, Model, LastMaint, LastMaintA) VALUES (9, 'AIRBUS', 'A320', '2002-9-4', 'LOG');

INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (1, 1000, '2002-10-5', 'DFW', 'LOG', 'E', '2002-9-5', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (1, 1010, '2002-10-6 ', 'ORD', 'JFK', 'E', '2002-9-15', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (1, 1020, '2002-10-5', 'LOG', 'JFK', 'E', '2002-9-14', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (1, 1040, '2002-10-7', 'LAX', 'LGA', 'E', '2002-10-1', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (2, 1020, '2002-10-5', 'LOG', 'INT', 'E', '2002-9-4', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (3, 1010, '2002-10-5', 'LAX', 'JFK', 'E', '2002-9-19', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (3, 1020, '2002-10-5', 'JFK', 'LAX', 'E', '2002-9-10', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (4, 1020, '2002-10-5', 'LOG', 'LAX', 'E', '2002-9-29', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (5, 1020, '2002-10-5', 'LOG', 'DFW', 'F', '2002-9-19', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (6, 1010, '2002-10-5', 'LAX', 'JFK', 'E', '2002-9-27', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (7, 1010, '2002-10-5', 'LAX', 'ORD', 'E', '2002-9-5', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (8, 1030, '2002-10-5 ', 'LAX', 'DFW', 'F', '2002-9-14', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (9, 1010, '2002-10-6', 'LAX', 'JFK', 'E', '2002-9-9', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (10, 1010, '2002-10-6', 'ORD', 'JFK', 'E', '2002-9-7', '2002-9-19');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (11, 1000, '2002-10-6', 'DFW', 'LOG', 'E', '2002-9-9', '0000-00-00');
INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) VALUES (12, 1000, '2002-10-6', 'DFW', 'LOG', 'E', '2002-9-19', '0000-00-00');

INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES(1000, 1, 'DFW', 'LOG', '2001-1-1 10:20:00', '2002-1-1 13:40:00', 7);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1010, 1, 'LAX', 'ORD', '2001-1-1 13:10:00', '2002-1-1 16:20:00', 3);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1010, 2, 'ORD', 'JFK', '2001-1-1 17:10:00', '2002-1-1 20:20:00', 3);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1020, 1, 'LOG', 'JFK', '2001-1-1 5:40:00', '2002-1-1 6:20:00', 9);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1020, 3, 'DFW', 'INT', '2001-1-1 11:10:00', '2002-1-1 11:40:00', 7);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1020, 4, 'INT', 'LAX', '2001-1-1 12:20:00', '2002-1-1 15:10:00', 7);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1030, 1, 'LAX', 'INT', '2001-1-1 11:20:00', '2002-1-1 16:10:00', 6);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1030, 2, 'INT', 'DFW', '2001-1-1 17:20:00', '2002-1-1 18:00:00', 6);
INSERT INTO FlightLeg (FLNO, Seq, FromA, ToA, DeptTime, ArrTime, Plane) VALUES (1040, 1, 'LAX', 'LGA', '2002-1-1 15:30:00', '2002-1-1 21:00:00', 1);

INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (1, 1000, '2002-10-5 00:00:00', '2002-1-1 10:10:00', '2002-1-1 13:10:00', 3);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (1, 1010, '2002-10-5 00:00:00', '2002-1-1 13:20:00', '2002-1-1 17:10:00', 1);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (1, 1020, '2002-10-5 00:00:00', '2002-1-1 5:40:00', '2002-1-1 6:30:00', 5);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (1, 1030, '2002-10-5 00:00:00', '2002-1-1 11:20:00', '2002-1-1 16:10:00', 8);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (1, 1040, '2002-10-7 00:00:00', '0000-0-0 0:00:00', '0000-0-0 00:00:00', 1);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (2, 1010, '2002-10-5 00:00:00', '2002-1-1 18:00:00', '2002-1-1 21:00:00', 1);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (2, 1030, '2002-10-5 00:00:00', '2002-1-1 17:20:00', '2002-1-1 18:40:00', 8);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (3, 1020, '2002-10-5 00:00:00', '2002-1-1 11:30:00', '2002-1-1 12:20:00', 5);
INSERT INTO FlightLegInstance (Seq, FLNO, FDate, ActDept, ActArr, Pilot) VALUES (4, 1020, '2002-10-5 00:00:00', '2002-1-1 13:00:00', '2002-1-1 16:00:00', 2);
