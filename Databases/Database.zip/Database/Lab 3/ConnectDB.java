/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightreservation;
import java.sql.*;

/**
 *
 * @author ZubairQureshi
 */
public class ConnectDB {
    private static ConnectDB instance = new ConnectDB();
    
    private ConnectDB()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
        }catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        
    }
    
    public static ConnectDB getInstance(){
        return instance;
    }
    
    public Connection getConnection() throws SQLException, ClassNotFoundException{
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:8889/sfda", "root","root");
        return con;
    }
}
