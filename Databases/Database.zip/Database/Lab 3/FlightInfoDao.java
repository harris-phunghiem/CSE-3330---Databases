package flightreservation;
import java.sql.*;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Date;
/**
 *
 * @author ZubairQureshi
 */
public class FlightInfoDao {


   
    public HashMap<Integer, AvaliableFlight> getAvaliableFlight(int flno, String deptCity, String arrCity, String travelDate) {
        
        HashMap<Integer, AvaliableFlight> avaliableFlights = new HashMap();
        Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
        
        try {
            
            
            StringBuilder sb = new StringBuilder();
            sb.append(" select a.seq, a.depttime, a.arrtime, a.froma, a.toa ");
            sb.append(" from flightleg a ");
            sb.append(" where a.flno = ? ");
            sb.append(" and a.froma = ? ");
            sb.append(" and a.toa = ? ");
            sb.append(" and date_format(a.DeptTime, 'yyyy-mm-dd') = date_format(? , 'yyyy-mm-dd')");
            sb.append(" union ");
            sb.append(" select a.seq, a.depttime, b.arrtime, a.froma, b.toa ");
            sb.append(" from flightleg a, flightleg b ");
            sb.append(" where a.toa = b.froma ");
            //sb.append(" and a.flno = ? ");
            sb.append(" and (timediff(b.depttime, a.arrtime) / 3600) < 2 ");
            sb.append(" and (timediff(b.depttime, a.arrtime) / 3600) > 1 ");
            sb.append(" and a.froma = ? ");
            sb.append(" and b.toa = ? ");
            sb.append(" and date_format(a.DeptTime, 'yyyy-mm-dd') = date_format(? , 'yyyy-mm-dd')");
       
            
            int count = 0;
            con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(sb.toString());
            prSt.setInt(1, flno);
            prSt.setString(2, deptCity);
            prSt.setString(3, arrCity);
            prSt.setString(4, travelDate);
            //prSt.setInt(5, flno);
            prSt.setString(5, deptCity);
            prSt.setString(6, arrCity);
            prSt.setString(7, travelDate);
            
            rs = prSt.executeQuery();
            
            System.out.println("Option  Seq  Dept Airport  Departure Time           Arr Airport  Arrival Time");
            while(rs.next()){
                count++;
                System.out.println(count+ "       " + rs.getString("seq")+"    "+rs.getString("froma")+"           "+rs.getString("depttime")+"    "+rs.getString("toa")+"          "+rs.getString("arrtime"));
                AvaliableFlight avaliableFlight = new AvaliableFlight();
                avaliableFlight.setOption(count);
                avaliableFlight.setFlightNo(flno);
                avaliableFlight.setLegSeq(rs.getInt("seq"));
                avaliableFlight.setDeptAirport(rs.getString("froma"));
                avaliableFlight.setDeptTime(rs.getString("depttime"));
                avaliableFlight.setArrivalAirport(rs.getString("toa"));
                avaliableFlight.setArrivalTime(rs.getString("arrtime"));
     
                avaliableFlights.put(new Integer(count), avaliableFlight);
            
            }
            
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
        
      return   avaliableFlights;
   }
   
   
   
    public boolean isSeatAvaliable(String seatType, int flno) {
   
        Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
        String sType = "";
        try {
            
            
             StringBuilder sb = new StringBuilder();
                sb.append(" select distinct ps.seatType ");
                sb.append(" from flightleg f ");
                sb.append(" , plane p ");
                sb.append(" , planeseats ps ");
                sb.append(" where ");
                sb.append(" f.plane=p.id ");
                sb.append(" and  p.model=ps.model ");
                sb.append(" and ps.seatType= ? ");
                sb.append(" and f.flno=? ");
            
            con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(sb.toString());
            prSt.setString(1, seatType);
            prSt.setInt(2, flno);
            
            
            rs = prSt.executeQuery();
            
            while(rs != null && rs.next()){
                sType =  rs.getString("seatType");
             }
            
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
       
        if (sType.equalsIgnoreCase(seatType))
            return true;
        else 
            return false;
   }
   
   
   
public boolean isPassengerValid(int id) {
   
        Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
         int  pId = 0;
        try {
           
            
             StringBuilder sb = new StringBuilder();
             sb.append(" select id from passenger p where p.id=?");
               
             con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(sb.toString());
            prSt.setInt(1, id);
           
            rs = prSt.executeQuery();
            
            while(rs != null && rs.next()){
                pId =  rs.getInt("id");
     
            }
            
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
       
        if (pId == id)
            return true;
        else 
            return false;
   }   
   
   
   public boolean makeReservation(int id, String seatType, AvaliableFlight avaliableFlight, int option) {
        Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
        String sType = "";
        int count = 0;
        Scanner s = new Scanner(System.in);
        try {
            
            
            StringBuilder sb = new StringBuilder();
                sb.append(" INSERT INTO Reservation (PassID, FLNO, FDate, FromA, ToA, SeatClass, DateBooked, DateCancelled) ");
                sb.append(" VALUES (?, ?, (select fdate from flightinstance where flno = ? limit 1), ?, ?, ?, ?, NULL); ");
               
            con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(sb.toString());
            prSt.setInt(1, id);
            prSt.setInt(2, avaliableFlight.getFlightNo());
            prSt.setInt(3, avaliableFlight.getFlightNo());
            prSt.setString(4, avaliableFlight.getDeptAirport());
            prSt.setString(5, avaliableFlight.getArrivalAirport());
            prSt.setString(6, seatType);
            prSt.setDate(7, new java.sql.Date(new Date().getTime()));
            
            count = prSt.executeUpdate();
            System.out.println("Flight reservation has been made!!!");
        
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
        if (count == 1)
            return true;
        else 
            return false;
   }
   
    public HashMap<Integer, Reservation> getReservation(int passId) {
        
        HashMap<Integer, Reservation> reservations = new HashMap();
        Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
        
        try {
            
            //Select * from Reservation where PassId = 1 and Datecancelled is NULL;
            
            StringBuilder sb = new StringBuilder();
            sb.append(" select passid, flno, fdate, froma, toa, seatclass, datebooked, datecancelled ");
            sb.append(" from reservation ");
            sb.append(" where passid = ? ");
            sb.append(" and Datecancelled is NULL ");
       
            int count = 0;
            con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(sb.toString());
            prSt.setInt(1, passId);
            rs = prSt.executeQuery();
            
            System.out.println("Reservation Seq   Flight No.   Date    Departure Airport   Arrival Airport    Seat Class");
            while(rs.next()){
                count++;
                System.out.println(count+ "       " + rs.getInt("flno")+"    "+rs.getString("fdate")+"           "+rs.getString("froma")+"    "+rs.getString("toa")+"          "+rs.getString("seatclass"));
                Reservation reservation = new Reservation();
                reservation.setOption(count);
                reservation.setDateBooked(rs.getString("datebooked"));
                reservation.setFlno(rs.getInt("flno"));
                reservation.setFromA(rs.getString("froma"));
                reservation.setToA(rs.getString("toa"));
                reservation.setfDate(rs.getString("fdate"));
                reservation.setSeatClass(rs.getString("seatclass"));
                reservation.setPassId(rs.getInt("passid"));
                
                reservations.put(new Integer(count), reservation);
            
            }
            
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
        
      return   reservations;
   }
   
   public boolean updateReservation(int Id, int flno, String fDate){
       Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
        int count = 0;
        Scanner s = new Scanner(System.in);
        try {
            
            //update reservation set datecancelled = now() where passid = 1 and flno = 1010 and DATE_FORMAT(fdate, 'yyyy-mm-dd')  = DATE_FORMAT('2002-10-06', 'yyyy-mm-dd');
            StringBuilder sb = new StringBuilder();
                sb.append(" update reservation ");
                sb.append(" set datecancelled = now() ");
                sb.append(" where passid = ? ");
                sb.append(" and flno = ? ");
                sb.append(" and DATE_FORMAT(fdate, 'yyyy-mm-dd')  = DATE_FORMAT(?, 'yyyy-mm-dd'); ");
               
            con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(sb.toString());
            prSt.setInt(1, Id);
            prSt.setInt(2, flno);
            prSt.setString(3, fDate);
            
            count = prSt.executeUpdate();
            System.out.println("Flight reservation has been cancelled!!!");
        
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
        if (count == 1)
            return true;
        else 
            return false;
   }
   
   public void getPlaneInfo(){
       Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
        int count = 0;
        Scanner s = new Scanner(System.in);
        try {
            
            String query = "select id, maker, model from plane order by id;";
            con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(query);
            rs = prSt.executeQuery();
            
            System.out.println("id    maker    model");
            while(rs.next()){
                System.out.println(rs.getInt("id")+ "  "+rs.getString("maker")+"  "+rs.getString("model"));
            }
            
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
   }
   
   public void getPilotInfo(){
       Connection con = null;
        PreparedStatement prSt = null;
        ResultSet rs = null;
        int count = 0;
        Scanner s = new Scanner(System.in);
        try {
            
            String query = "select id, name from pilot order by id;";
            con = ConnectDB.getInstance().getConnection();
            prSt = con.prepareStatement(query);
            rs = prSt.executeQuery();
            
            System.out.println("id    name");
            while(rs.next()){
                System.out.println(rs.getInt("id")+ "  "+rs.getString("name"));
            }
            
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try{
                if(rs != null) rs.close();
                if(prSt != null) prSt.close();
                if(con != null) con.close();
            } catch(Exception ex){}
        }
   }
   
}
   
   
    
