/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightreservation;

/**
 *
 * @author ZubairQureshi
 */
public class Reservation {
    private int option;
    private int passId;
    private int flno;
    private String fDate;
    private String fromA;
    private String toA;
    private String seatClass;
    private String dateBooked;
    private String dateCancelled;

    public int getOption() {
        return option;
    }

    public void setOption(int option) {
        this.option = option;
    }

    
    public int getPassId() {
        return passId;
    }

    public void setPassId(int passId) {
        this.passId = passId;
    }

    public int getFlno() {
        return flno;
    }

    public void setFlno(int flno) {
        this.flno = flno;
    }

    public String getfDate() {
        return fDate;
    }

    public void setfDate(String fDate) {
        this.fDate = fDate;
    }

    public String getFromA() {
        return fromA;
    }

    public void setFromA(String fromA) {
        this.fromA = fromA;
    }

    public String getToA() {
        return toA;
    }

    public void setToA(String toA) {
        this.toA = toA;
    }

    public String getSeatClass() {
        return seatClass;
    }

    public void setSeatClass(String seatClass) {
        this.seatClass = seatClass;
    }

    public String getDateBooked() {
        return dateBooked;
    }

    public void setDateBooked(String dateBooked) {
        this.dateBooked = dateBooked;
    }

    public String getDateCancelled() {
        return dateCancelled;
    }

    public void setDateCancelled(String dateCancelled) {
        this.dateCancelled = dateCancelled;
    }
    
    
    
}
