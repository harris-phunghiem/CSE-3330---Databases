/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightreservation;

/**
 *
 * @author ZubairQureshi
 */
public class AvaliableFlight {
  
    private int option;
    private int flightNo;
    private int legSeq;
    private String deptAirport;
    private String deptTime;
    private String arrivalAirport;
    private String arrivalTime;

    public int getOption() {
        return option;
    }

    public void setOption(int option) {
        this.option = option;
    }

    
    public int getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(int flightNo) {
        this.flightNo = flightNo;
    }
    public int getLegSeq() {
        return legSeq;
    }

    public void setLegSeq(int legSeq) {
        this.legSeq = legSeq;
    }

    public String getDeptAirport() {
        return deptAirport;
    }

    public void setDeptAirport(String deptAirport) {
        this.deptAirport = deptAirport;
    }

    public String getDeptTime() {
        return deptTime;
    }

    public void setDeptTime(String deptTime) {
        this.deptTime = deptTime;
    }

    public String getArrivalAirport() {
        return arrivalAirport;
    }

    public void setArrivalAirport(String arrivalAirport) {
        this.arrivalAirport = arrivalAirport;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }   
}
