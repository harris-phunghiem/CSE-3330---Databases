/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flightreservation;

import java.util.Scanner;
import java.util.HashMap;
/**
 *
 * @author ZubairQureshi
 */
public class FlightReservation {
    
    
    public static void main (String arg[]) {
        
            Scanner s = new Scanner(System.in);
            int menuOption = 100;
            FlightInfoDao flightInfoDao = new FlightInfoDao();
            String tmp = null;
            while (menuOption != 0){
                System.out.println("Please select one of the following option numbers: ");
                System.out.println("1. Reservation");
                System.out.println("2. Cancellation");
                System.out.println("3. Report");
                System.out.println("0. Exit");
                menuOption = s.nextInt();

                if(menuOption == 1){ 
                    
                    do{
                    System.out.println("Please enter Flight number");
                    tmp = s.next();
                    } while (!tmp.matches("[0-9]+"));
                    int flno = Integer.valueOf(tmp);
                    
                    do{
                    System.out.println("Please enter departure airport code");
                    tmp = s.next();
                    } while(!tmp.matches("[a-zA-Z]{3}"));
                    String dAirCode = tmp;
                    
                    do{
                    System.out.println("Please enter arrival airport code");
                    tmp = s.next();
                    }while(!tmp.matches("[a-zA-Z]{3}"));
                    String aAirCode = tmp;
                    
                    System.out.println("Please enter the date (yyyy-mm-dd)");
                    String date = s.next();

                    HashMap<Integer, AvaliableFlight> avaliableFlights = flightInfoDao.getAvaliableFlight(flno, dAirCode,aAirCode, date);

                    do{
                    System.out.println("Please select the option you like to make a reservation for: ");
                    tmp = s.next();
                    }while(!tmp.matches("[0-9]+"));
                    int option = Integer.valueOf(tmp);

                    AvaliableFlight avaliableFlight = avaliableFlights.get(new Integer(option));

                    do{
                    System.out.println("Please Enter Seat Type E/F");
                    tmp = s.next();
                    }while(!tmp.matches("[a-zA-Z]{1}"));
                    String seatType = tmp;

                    flightInfoDao.isSeatAvaliable(seatType, flno);

                    do{
                    System.out.println("Please Enter Your Passenger Id");
                    tmp= s.next();
                    }while(!tmp.matches("[0-9]+"));
                    int id = Integer.valueOf(tmp);
                    
                    flightInfoDao.isPassengerValid(id);


                    flightInfoDao.makeReservation(id, seatType, avaliableFlight, option);
                }
                if (menuOption == 2){
                    
                    do{
                    System.out.println("Please Enter Your Passenger Id");
                    tmp= s.next();
                    }while(!tmp.matches("[0-9]+"));
                    int id = Integer.valueOf(tmp);
                    
                    
                    HashMap<Integer, Reservation> reservations = flightInfoDao.getReservation(id);
                    
                    do{
                    System.out.println("Please Choose Seq Number to cancel the reservation");
                    tmp= s.next();
                    }while(!tmp.matches("[0-9]+"));
                    int seq = Integer.valueOf(tmp);
                    
                    Reservation reservation = reservations.get(new Integer(seq));
                    
                    flightInfoDao.updateReservation(reservation.getPassId(), reservation.getFlno(), reservation.getfDate());
                }
                
                if (menuOption == 3){
                    
                    do{
                    System.out.println("Please select from options below: ");
                    System.out.println("1. Plane");
                    System.out.println("2. Pilot");
                    tmp = s.next();
                    }while(!tmp.matches("[0-9]+"));
                    int useropt = Integer.valueOf(tmp);
                            
                    
                    if (useropt == 1)
                        flightInfoDao.getPlaneInfo();
                   
                    if (useropt == 2)
                        flightInfoDao.getPilotInfo();
                }
            }
    
    }
    
}
